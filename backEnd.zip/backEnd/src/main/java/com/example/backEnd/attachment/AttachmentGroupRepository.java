package com.example.backEnd.attachment;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AttachmentGroupRepository extends JpaRepository<AttachmentGroup, Long> {
}
