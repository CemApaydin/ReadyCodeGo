import React from "react";
import Navbar from "./StudentNavbar";

export default function InfoPage(){


    return (

        <div>
            <Navbar/>
            <h1>InfoPage</h1>
        </div>
    )
}