import React from "react";
import Navbar from "./StudentNavbar";
import OperationNavbar from "./OperationNavbar";

export default function ChangeApplicationPage(){
    return (
        <div>
            <Navbar/>
            <OperationNavbar/>
            <h1>ChangeApplicationPage</h1>
        </div>
    )
}