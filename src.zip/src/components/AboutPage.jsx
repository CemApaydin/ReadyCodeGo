import Navbar from "./navbar1"
import React from "react";

export default function AboutPage(){
    return (
        <div>
            <Navbar />
            <h1>About</h1>
        </div>
    )
}